public class InvalidInputPackException extends Exception {
    public InvalidInputPackException() {
        super();
    }
}
