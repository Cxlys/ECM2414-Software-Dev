public interface ThreadTests {
    /* category marker */
}
